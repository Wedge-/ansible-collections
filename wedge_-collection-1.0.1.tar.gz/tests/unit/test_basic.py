"""Unit tests for wedge.collection."""


def test_basic() -> None:
    """Dummy unit test that always passes.

    Raises:
        AssertionError: If the assertion fails.
    """
    assert bool(1) is True
